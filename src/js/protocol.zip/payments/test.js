'use strict'

const Payments = require('./index')
