'use strict'

const pull = require('pull-stream')
const crypto = require('crypto')

const constants = require('../constants')

const curve = 'brainpoolP512t1'

module.exports.registerFunctionality = function (node, cb) {

    node.handle(constants.keyExchangeProtocol, (err, conn) => {
        if (err) { throw err }

        let secretExponent = crypto.createECDH(curve)
        let groupElement = secretExponent.generateKeys()

        pull(
            conn,
            pull.map(groupElement => secretExponent.computeSecret(groupElement)),
            pull.collect((err, secret) => {
                pull(
                    pull.once(groupElement),
                    conn
                )
                cb(null, secret)
            })
        )
    })
}

module.exports.sendKeyExchangeRequest = function (node, receiver, cb) {
    
    node.dialProtocol(receiver, constants.keyExchangeProtocol, (err, conn) => {
        if (err) { throw err }

        let secretExponent = crypto.createECDH(curve)
        let groupElement = secretExponent.generateKeys()

        pull(
            pull.once(groupElement),
            conn,
            pull.map(groupElement => secretExponent.computeSecret(groupElement)),
            pull.collect(cb)
        )
    })
}