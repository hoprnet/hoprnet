'use strict'

const constants = require('./constants')

function warmUpConnections(nodes, cb) {

    function recursive(index) {
        if (index + 1 < nodes.length) {
            nodes[index].dialProtocol(nodes[index + 1].peerInfo, constants.relayProtocol, (err, conn) => {
                if (err) { return cb(err) }
                pull(
                    pull.values([nodes[index + 1].peerInfo.id.toBytes(), 'test']),
                    conn
                )
                recursive(index + 1)
            })
        } else {
            cb()
        }
    }
    recursive(0)
}