'use strict'

const PeerId = require('peer-id')
const pull = require('pull-stream')

const Record = require('./record')

const records = new Map()

module.exports.getRecord = function (sender, receiver, query, cb) {
    sender.dialProtocol(receiver.peerInfo, '/get', (err, conn) => {
        if (err) { throw err }

        pull(
            pull.values([sender.peerInfo.id].concat(query).map(node => node.toBytes())),
            conn,
            pull.map(v => Record.createFromStr(v.toString())),
            pull.collect(cb)
        )
    })
}

module.exports.putRecord = function (sender, receiver, record, cb) {
    sender.dialProtocol(receiver.peerInfo, '/put', (err, conn) => {
        if (err) { throw err }

        pull(
            pull.values([sender.peerInfo.id.toB58String()].concat(record)),
            conn
        )
        cb(null)
    })
}

function registerPut(node) {
    node.handle('/put', (err, conn) => {
        pull(
            conn,
            pull.map(v => v.toString()),
            pull.collect((err, data) => {
                let id = data[0]
                let record = Record.createFromStr(data[1])
                if (Record.isValid(id, record, records)) {
                    records.set(id, record)
                }
            }),
            // pull.drain((msg) => {
            //     records.set(msg[0], msg[1])
            //     // TODO: forward record
            // })
        )
    })
}

function createResponse(obsAddrs) {
    let first = true;
    return function (read) {
        return function readable(end, cb) {
            read(end, function (end, data) {
                if (first) {
                    let record = records.get(data) || {}
                    record.addr = obsAddrs
                    
                    records.set(data[0], record)

                    first = false

                    cb(end, record.toString())
                } else if (data != null) {
                    let record = records.get(data)
                    if (record) {
                        cb(end, record.toString())
                    }
                } else {
                    cb (end, null)
                }
            })
        }
    }
}

function registerGet(node) {
    node.handle('/get', (err, conn) => {

        conn.getObservedAddrs((err, obsAddrs) => {
            pull(
                conn,
                pull.map(v => PeerId.createFromBytes(v).toB58String()),
                createResponse(obsAddrs),
                conn
            )
        })
    })
}

module.exports.registerHandlers = function (node) {
    registerGet(node)
    registerPut(node)
}