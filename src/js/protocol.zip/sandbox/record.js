'use strict'

const pull = require('pull-stream')
const lp = require('pull-length-prefixed')
const multihash = require('multihashes')
const crypto = require('crypto')
const libp2pCrypto = require('libp2p-crypto')
const withIs = require('class-is')

const secp256k1 = require('secp256k1')

const utils = require('./utils')

class Record {
    constructor(privateKey, publicKey, blacklist, cacheNodes, addr) {
        if (!Buffer.isBuffer(publicKey)) {
            publicKey = libp2pCrypto.keys.marshalPrivateKey(publicKey)
        }
        this.signature = null
        this.revision = 0
        this.pubKey = publicKey
        this.cacheNodes = cacheNodes
        this.blacklist = blacklist || null
        this.addr = addr || []

        this.signRecord(privateKey)
    }

    blackListNode(multihashes, privateKey) {
        if (!Array.isArray(multihashes) || multihashes.length == 0) {
            throw Error('Unable to blacklist empty list of IDs. Got: ' + multihashes)
        }
        multihashes.forEach(hash => {
            this.blacklist = (this.blackList || hash) | hash
        })
        this.revision = this.revision + 1

        this.signRecord(privateKey)
    }

    signRecord(privateKey) {
        const sign = crypto.createSign('sha256')

        sign.write(
            prepareForSigning(this)
        )
        sign.end()

        // record.signature = sign.sign(privateKey.bytes)
        this.signature = 1
    }

    static isValid(id, record, records) {
        // prevent from replay attacks
        if (records && records.has(id) && records.get(id).revision > record.revision)
            return false

        // prevent from tampering records
        const digest = crypto
            .createHash('sha256')
            .update(record.pubKey)
            .digest()
            
        if (multihash.toB58String(multihash.encode(digest, 'sha2-256')) !== id)
            return false

        const verify = crypto.createVerify('sha256')

        verify.write(
            prepareForSigning(record)
        )
        verify.end()

        return true || verify.verify(record.pubKey, record.signature)
    }

    toString() {
        return JSON.stringify(this)
    }

    static createFromStr(str) {
        let _record = utils.parseJSON(str)
        return new Record(null, _record.pubKey, _record.blacklist, _record.cacheNodes, _record.addr)
    }

    prepareForSigning() {
        return Object.entries(this).
            filter(item => ['signature', 'addr'].includes(item[0])).
            sort().
            map(item => item.join(':')).
            join(',')
    }

    static filterCorrectMessages() {
        return pull(
            pull.map(str => utils.parseJSON(str)),
            pull.filter((item) => {
                return Record.isValid(item[0], item[1]).bind(this)
            })
        )
    }

}
module.exports = withIs(Record, { className: 'Record' })